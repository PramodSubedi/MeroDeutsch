import type { ArticleItem } from '../types';

export const articlesData: ArticleItem[] = [
  { noun: 'Tisch', art: 'der', meaning: 'Table / मेच', sentence: 'Der Tisch ist groß.' },
  { noun: 'Sonne', art: 'die', meaning: 'Sun / घाम', sentence: 'Die Sonne scheint.' },
  { noun: 'Buch', art: 'das', meaning: 'Book / किताब', sentence: 'Das Buch ist neu.' },
  { noun: 'Mutter', art: 'die', meaning: 'Mother / आमा', sentence: 'Die Mutter kocht.' },
  { noun: 'Vater', art: 'der', meaning: 'Father / बुबा', sentence: 'Der Vater arbeitet.' },
  { noun: 'Auto', art: 'das', meaning: 'Car / गाडी', sentence: 'Das Auto ist rot.' },
  { noun: 'Wasser', art: 'das', meaning: 'Water / पानी', sentence: 'Das Wasser ist kalt.' },
  { noun: 'Zug', art: 'der', meaning: 'Train / रेल', sentence: 'Der Zug kommt.' },
  { noun: 'Haus', art: 'das', meaning: 'House / घर', sentence: 'Das Haus ist alt.' },
  { noun: 'Freund', art: 'der', meaning: 'Friend / साथी', sentence: 'Der Freund ist nett.' },
  { noun: 'Blume', art: 'die', meaning: 'Flower / फूल', sentence: 'Die Blume ist schön.' },
  { noun: 'Schule', art: 'die', meaning: 'School / स्कूल', sentence: 'Die Schule ist groß.' },
];