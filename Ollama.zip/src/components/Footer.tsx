export function Footer() {
  return (
    <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-12 mt-24 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 bg-slate-50 dark:bg-slate-950/50 border border-slate-100 dark:border-slate-800/80 rounded-3xl p-8 shadow-xs">
          
          {/* Brand Column */}
          <div className="space-y-3 md:col-span-2">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              Mero Deutsch 
              <span className="text-xs bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300 px-2.5 py-0.5 rounded-full font-semibold">
                A1 Core
              </span>
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-400 max-w-sm leading-relaxed">
              Tailored German language training for Nepali and English speakers, featuring interactive speech recognition and smart daily challenges.
            </p>
          </div>

          {/* Quick Navigation */}
          <div>
            <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-3">
              Explore
            </h4>
            <ul className="space-y-2.5 text-sm text-slate-600 dark:text-slate-400 font-medium">
              <li><a href="/" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Dashboard</a></li>
              <li><a href="/alphabet" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Alphabet & Sounds</a></li>
              <li><a href="/articles" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Article Trainer</a></li>
              <li><a href="/glossary" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Glossary & Words</a></li>
            </ul>
          </div>

          {/* System status */}
          <div>
            <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-3">
              System
            </h4>
            <div className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
              <div className="flex items-center gap-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3 py-2 rounded-xl">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300">Speech API Active</span>
              </div>
              <p className="text-xs text-slate-500 pt-1">Production v1.2.0</p>
            </div>
          </div>

        </div>

        {/* Bottom copyright row */}
        <div className="mt-8 pt-4 flex flex-col sm:flex-row justify-between items-center text-xs text-slate-500 dark:text-slate-400 px-2">
          <p>© {new Date().getFullYear()} MeroDeutsch. Designed for seamless multilingual learning.</p>
          <div className="flex space-x-6 mt-4 sm:mt-0 font-medium">
            <span className="hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors">Privacy</span>
            <span className="hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors">Terms</span>
            <span className="hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors">Support</span>
          </div>
        </div>
      </div>
    </footer>
  );
}