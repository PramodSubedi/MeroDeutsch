import { useLang } from '../hooks/useLang';
import { greetingsData, sharedTextDatabase } from '../data/sharedContent';
import { FlipCard } from '../components/FlipCard';
import { SectionGrid } from '../components/SectionGrid';

export function GreetingsPage() {
  const { langMode } = useLang();
  const isDE = langMode === 'german';
  const title = isDE ? 'Grußformeln' : sharedTextDatabase.greetings.title;
  const description = isDE
    ? 'Lerne die wichtigsten Begrüßungen auf Deutsch.'
    : sharedTextDatabase.greetings.description;

  return (
    <SectionGrid title={title} description={description}>
      {greetingsData.map((item, index) => (
        <FlipCard
          key={item.de}
          badge={index + 1}
          front={item.de}
          back={isDE ? undefined : `${item.en} · ${item.ne}`}
          langMode={langMode}
        />
      ))}
    </SectionGrid>
  );
}